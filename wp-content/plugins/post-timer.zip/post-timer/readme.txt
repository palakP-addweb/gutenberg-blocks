=== Post Timer ===
Contributors: addweb-solution-pvt-ltd, saurabhdhariwal, snehalb890
Tags: popup, timer popup, post timer, post, timer, clock, custom post timer
Requires at least: 5.0
Tested up to: 6.3
Stable tag: 3.8
License: GPLv2 or later
License URI: http://www.gnu.org/licenses/gpl-2.0.html

Post Timer is a simple and easy wordpress plugin used for selected post/pages and custom post to show a timer popup when user add new post or edit post.

== Description ==
Post Timer is a simple and easy wordpress plugin used for selected post and custom post to show a timer popup when user add new post or edit post.

You can change timer popup colour and popup place like left,right,top-left,top-right,bottom-left,bottom-right.

You can also show timer popup on selected post and custom posts.

== Changelog ==

= 3.8 =
* Compatibility check with Wordpress 6.3

= 3.7 =
* UI fixes and enhancements

= 3.6 =
* Minor fixes and enhancements

= 3.5 =
* Minor fixes and enhancements

== Installation ==

**Installation Instruction & Configuration**  	

1. Download the zip file and extract the contents. Upload the 'post_timer' folder to your plugins directory (wp-content/plugins/).

2. Activate the plugin through the 'Plugins' menu in WordPress. 	

3. Go to Settings -> Post Timer and set popup color, popup place, choose posts, pages, custom post types where you want to display popup timer during add/edit

== Screenshots ==

1. Apperance of timer popup on your website.
2. Setting of plugin.

== Frequently Asked Questions ==

= What is use of this plugin =

Post Timer is used for show a timer popup when user add new post or edit post, So user can calculate that how much time he/she consume for that post.

= How to change setting of popup =
You can change setting of plugin from 'Dashboard > Settings > Post Timer'.

