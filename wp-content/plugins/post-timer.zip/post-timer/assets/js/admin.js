//Color picker used when user select background color of timer and setting tabs
jQuery(document).ready(function($) {
  $( '.fa-plugin-setting' ).tabs();
  $('#popup_color').wpColorPicker();
});